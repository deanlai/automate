print(abs(round(-3.5)))
print(round(abs(-0.5)))
