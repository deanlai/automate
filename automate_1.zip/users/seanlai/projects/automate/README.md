# automate
Projects for Automate the Boring Stuff
