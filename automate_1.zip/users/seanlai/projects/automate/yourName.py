name = ''
while name != 'your name':
    print('Please type your name.')
    name = input()
print('Thank you!')
